﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class view2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(view2))
        Me.print2 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.view_reviews_text = New System.Windows.Forms.Label()
        Me.back2 = New System.Windows.Forms.Button()
        Me.Panel2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'print2
        '
        Me.print2.BackgroundImage = CType(resources.GetObject("print2.BackgroundImage"), System.Drawing.Image)
        Me.print2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.print2.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.print2.Location = New System.Drawing.Point(283, 337)
        Me.print2.Name = "print2"
        Me.print2.Size = New System.Drawing.Size(155, 45)
        Me.print2.TabIndex = 15
        Me.print2.Text = "Print"
        Me.print2.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel2.Controls.Add(Me.DataGridView1)
        Me.Panel2.Location = New System.Drawing.Point(69, 104)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(556, 215)
        Me.Panel2.TabIndex = 14
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(20, 21)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(521, 172)
        Me.DataGridView1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel1.Controls.Add(Me.view_reviews_text)
        Me.Panel1.Controls.Add(Me.back2)
        Me.Panel1.Location = New System.Drawing.Point(69, 23)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(556, 66)
        Me.Panel1.TabIndex = 13
        '
        'view_reviews_text
        '
        Me.view_reviews_text.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.view_reviews_text.AutoSize = True
        Me.view_reviews_text.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.view_reviews_text.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.view_reviews_text.Location = New System.Drawing.Point(16, 20)
        Me.view_reviews_text.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.view_reviews_text.Name = "view_reviews_text"
        Me.view_reviews_text.Size = New System.Drawing.Size(136, 23)
        Me.view_reviews_text.TabIndex = 14
        Me.view_reviews_text.Text = "VIEW REVIEWS"
        '
        'back2
        '
        Me.back2.BackgroundImage = CType(resources.GetObject("back2.BackgroundImage"), System.Drawing.Image)
        Me.back2.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.back2.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.back2.Location = New System.Drawing.Point(451, 13)
        Me.back2.Name = "back2"
        Me.back2.Size = New System.Drawing.Size(90, 37)
        Me.back2.TabIndex = 13
        Me.back2.Text = "Go Back"
        Me.back2.UseVisualStyleBackColor = True
        '
        'view2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(692, 407)
        Me.Controls.Add(Me.print2)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "view2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "VIEW2"
        Me.Panel2.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents print2 As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Panel1 As Panel
    Friend WithEvents view_reviews_text As Label
    Friend WithEvents back2 As Button
End Class
