﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class view1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(view1))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.view_subscription_text = New System.Windows.Forms.Label()
        Me.back1 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.print1 = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel1.Controls.Add(Me.view_subscription_text)
        Me.Panel1.Controls.Add(Me.back1)
        Me.Panel1.Location = New System.Drawing.Point(55, 22)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(556, 66)
        Me.Panel1.TabIndex = 10
        '
        'view_subscription_text
        '
        Me.view_subscription_text.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.view_subscription_text.AutoSize = True
        Me.view_subscription_text.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.view_subscription_text.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.view_subscription_text.Location = New System.Drawing.Point(16, 20)
        Me.view_subscription_text.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.view_subscription_text.Name = "view_subscription_text"
        Me.view_subscription_text.Size = New System.Drawing.Size(199, 23)
        Me.view_subscription_text.TabIndex = 14
        Me.view_subscription_text.Text = "VIEW SUBSCRIPTIONS"
        '
        'back1
        '
        Me.back1.BackgroundImage = CType(resources.GetObject("back1.BackgroundImage"), System.Drawing.Image)
        Me.back1.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.back1.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.back1.Location = New System.Drawing.Point(451, 13)
        Me.back1.Name = "back1"
        Me.back1.Size = New System.Drawing.Size(90, 37)
        Me.back1.TabIndex = 13
        Me.back1.Text = "Go Back"
        Me.back1.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel2.Controls.Add(Me.DataGridView1)
        Me.Panel2.Location = New System.Drawing.Point(55, 103)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(556, 215)
        Me.Panel2.TabIndex = 11
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(20, 21)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(521, 172)
        Me.DataGridView1.TabIndex = 0
        '
        'print1
        '
        Me.print1.BackgroundImage = CType(resources.GetObject("print1.BackgroundImage"), System.Drawing.Image)
        Me.print1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.print1.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.print1.Location = New System.Drawing.Point(269, 336)
        Me.print1.Name = "print1"
        Me.print1.Size = New System.Drawing.Size(155, 45)
        Me.print1.TabIndex = 12
        Me.print1.Text = "Print"
        Me.print1.UseVisualStyleBackColor = True
        '
        'view1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(662, 417)
        Me.Controls.Add(Me.print1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "view1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "VIEW1"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents back1 As Button
    Friend WithEvents print1 As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents view_subscription_text As Label
End Class
