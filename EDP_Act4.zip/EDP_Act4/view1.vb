﻿Public Class view1
    Private Sub print1_Click(sender As Object, e As EventArgs) Handles print1.Click

    End Sub

    Private Sub back1_Click(sender As Object, e As EventArgs) Handles back1.Click
        Close()
        Main.Show()
    End Sub
End Class