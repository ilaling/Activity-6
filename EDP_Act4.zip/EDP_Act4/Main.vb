﻿Public Class Main

    Private Sub add_customers_Click(sender As Object, e As EventArgs) Handles add_customers.Click
        add.Show()
    End Sub

    Private Sub delete_customers_Click(sender As Object, e As EventArgs) Handles delete_customers.Click
        delete.Show()
    End Sub

    Private Sub view_subs_Click(sender As Object, e As EventArgs) Handles view_subs.Click
        view1.Show()
    End Sub

    Private Sub view_reviews_Click(sender As Object, e As EventArgs) Handles view_reviews.Click
        view2.Show()
    End Sub

    Private Sub upload_button_Click(sender As Object, e As EventArgs) Handles upload_button.Click
        upload.Show()
    End Sub

    Private Sub backup_button_Click(sender As Object, e As EventArgs) Handles backup_button.Click
        backup.Show()
    End Sub

    Private Sub logout_Click(sender As Object, e As EventArgs) Handles logout.Click
        Close()
        Login_Form.Show()
    End Sub
End Class