﻿Public Class view2
    Private Sub print2_Click(sender As Object, e As EventArgs) Handles print2.Click

    End Sub

    Private Sub back2_Click(sender As Object, e As EventArgs) Handles back2.Click
        Close()
        Main.Show()
    End Sub
End Class